This package and it's subpackages were created to be able to easily share and import the functions and code created by the students in the OCC Lab at Temple University under the supervision of Dr. Rebecca Beadling. This lab group is comprised of undergraduate and graduate students. More information can be found here: https://sites.temple.edu/oceanclimateconnections/

The lab aims to emphasize the importance of sharing and crediting code. Please cite the package if used in any publications.
